
 document.getElementById("btn").addEventListener("click", myFunction);

 function myFunction(){
 var teams=['Anderlecht(BEL)',
 'APOEL(CYP)',
 'Atlético Madrid(ESP)',
 'Barcelona(ESP)',
 'Basel(SUI)',
 //'Bayern München(GER)',
 //'Benfica(POR)',
 'Beşiktaş(TUR)',
 'Borussia Dortmund(GER)',
 'Celtic(SCO)',
 //'Chelsea(ENG)',
 'CSKA Moskva(RUS)',
 'Feyenoord(NED)',
 //'Juventus(ITA)',
 'Liverpool(ENG)',
 'Manchester City(ENG)',
 'Manchester United(ENG)',
 'Maribor(SVN)',
 //'Monaco(FRA)',
 'Napoli(ITA)',
 'Olympiacos(GRE)',
 'Paris Saint-Germain(FRA)',
 'Porto(POR)',
 'Qarabağ(AZE)',
 'RB Leipzig(GER)',
 ///'Real Madrid(ESP)',
 'Roma(ITA)',
 'Sevilla(ESP)',
 //'Shakhtar Donetsk(UKR)',
 //'Spartak Moskva(RUS)',
 'Sporting CP(POR)',
 'Tottenham Hotspur(ENG)'];

function shuffleArray ( array ) {
    var counter = array.length, temp, index;
    // While there are elements in the array
    while ( counter > 0 ) {
        // Pick a random index
        index = Math.floor( Math.random() * counter );
 
        // Decrease counter by 1
        counter--;
 
        // And swap the last element with it
        temp = array[ counter ];
        array[ counter ] = array[ index ];
        array[ index ] = temp;
    }
    return array;
}

function country(c){
	var l=c.length;
	var str=c.substr(l-5, l);
	return str;
}



function noarraysame(p,ar){


	var x;
	
	for(x=0;x<ar.length;x++){
		if(ar[x]==p){
			return false;

		}
		else{
			return true;
		}
		
	}
}
function removechamp(a,b){
	var x;
	for(x=0;x<a.length;x++){
		if(a[x]==b ){
			a.splice(x,1);
			break;
			return a;
		}
	}
}

/*function sameco(array,obj){
	var z;
	var l1=array.length;
	for(z=0;z<l1;z++){
		if(country(array[z])==country(obj)){
			return false;
		}
	}
	return true;
}
*/



var champions=['Bayern München(GER)','Benfica(POR)','Chelsea(ENG)','Juventus(ITA)','Monaco(FRA)','Real Madrid(ESP)','Shakhtar Donetsk(UKR)','Spartak Moskva(RUS)'];

var champions=shuffleArray(champions);
var teams=shuffleArray(teams);

function champsame(d){
	//var d;
	var x;
	for(x=0;x<champions.length;x++){
		if(champions[x]==d){
			return false;
		}
		return true;
	}

}

//var teams=shuffleArray( teams);
/*var fd='Bayern-Munchen(GER)';
var fd1='Benfica(POR)';
var fd2='Chelsea(ENG)';
var fd3='Juventus(ITA)';
var fd4='Monaco(FRA)';
var fd5='Real-Madrid(ESP)';
var fd6='Shakhtar-Donetsk(UKR)';
var fd7='Spartak-Moskva(RUS)';


var teams=new Array(24);
var x;
var y=0;
for(x=0;x<team.length;x++){
	if(team[x]!= (fd || fd2||fd3||fd4||fd5||fd6||fd7) ){
		teams[y]=team[x];
		y++;
	}
}*/

/*var x;
for(x=0;x<teams.length;x++){
		if(teams[x]==fd ){
			teams.splice(x,1);
			break;
			
		}
	}
	var x1;
for(x=0;x1<teams.length;x1++){
		if(teams[x1]==fd1 ){
			teams.splice(x1,1);
			break;
			
		}
	}
	var x2;
for(x=0;x2<teams.length;x2++){
		if(teams[x2]==fd2 ){
			teams.splice(x2,1);
			break;
			
		}
	}
	var x3;
for(x=0;x3<teams.length;x3++){
		if(teams[x3]==fd3 ){
			teams.splice(x3,1);
			break;
			
		}
	}
	var x4;
for(x4=0;x<teams.length;x4++){
		if(teams[x4]==fd4 ){
			teams.splice(x4,1);
			break;
			
		}
	}
	var x5;
for(x=0;x5<teams.length;x5++){
		if(teams[x5]==fd5 ){
			teams.splice(x5,1);
			break;
			
		}
	}

	var x6;
for(x6=0;x6<teams.length;x6++){
		if(teams[x]==fd6 ){
			teams.splice(x6,1);
			break;
			
		}
	}

	var x7;
for(x7=0;x<teams.length;x7++){
		if(teams[x7]==fd7 ){
			teams.splice(x7,1);
			break;
			
		}
	}*/





var arr1=new Array(4);
var arr2=new Array(4);
var arr3=new Array(4);
var arr4=new Array(4);
var arr5=new Array(4);
var arr6=new Array(4);
var arr7=new Array(4);
var arr8=new Array(4);


arr1[0]=champions[0];
arr2[0]=champions[1];
arr3[0]=champions[2];
arr4[0]=champions[3];
arr5[0]=champions[4];
arr6[0]=champions[5];
arr7[0]=champions[6];
arr8[0]=champions[7];

var i;
var temp=1;
var a1=country(arr1[0]);
for(i=0;i<teams.length;i++){
	if(a1!=country(teams[i]) && champsame(teams[i])==true  ){
		arr1[temp]=teams[i];
		teams.splice(i,1);
		temp++;
		if(temp==4){
			break;
		}
	}
}

var j;
var temp2=1;
var a2=country(arr2[0]);
for(j=0;j<teams.length;j++){
	if(a2!=country(teams[j]) && champsame(teams[j])==true ){
		arr2[temp2]=teams[j];
		teams.splice(j,1);
		temp2++;
		if(temp2==4){
			break;
		}
		
	}
}

var k;
var temp3=1;
var a3=country(arr3[0]);
for(k=0;k<teams.length;k++){
	if(a3!=country(teams[k]) && champsame(teams[k])==true ){
		arr3[temp3]=teams[k];
		teams.splice(k,1);
		temp3++;
		if(temp3==4){
			break;
		}
		
	}
}

var m;
var temp4=1;
var a4=country(arr4[0]);
for(m=0;m<teams.length;m++){
	if(a4!=country(teams[m]) && champsame(teams[m])==true ){
		arr4[temp4]=teams[m];
		teams.splice(m,1);
		temp4++;
		if(temp4==4){
			break;
		}
		
	}
}

var n;
var temp5=1;
var a5=country(arr5[0]);
for(n=0;n<teams.length;n++){
	if(a5!=country(teams[n]) && champsame(teams[n])==true ){
		arr5[temp5]=teams[n];
		teams.splice(n,1);
		temp5++;
		if(temp5==4){
			break;
		}
		
	}
}


var o;
var temp6=1;
var a6=country(arr6[0]);
for(o=0;o<teams.length;o++){
	if(a6!=country(teams[o]) && champsame(teams[o])==true ){
		arr6[temp6]=teams[o];
		teams.splice(o,1);
		temp6++;
		if(temp6==4){
			break;
		}
		
	}
}

var r;
var temp7=1;
var a7=country(arr7[0]);
for(r=0;r<teams.length;r++){
	if(a7!=country(teams[r]) && champsame(teams[r])==true ){
		arr7[temp7]=teams[r];
		teams.splice(r,1);
		temp7++;
		if(temp7==4){
			break;
		}
		
	}
}

var s;
var temp8=1;
var a8=country(arr8[0]);
for(s=0;s<teams.length;s++){
	if(a8!=country(teams[s]) && champsame(teams[s])==true ){
		arr8[temp8]=teams[s];
		teams.splice(s,1);
		temp8++;
		if(temp8==4){
			break;
		}
		
	}
}

if(teams.length<2){
arr8[3]=teams[0];
}else{
	arr8[3]=teams[0];
	arr8[2]=teams[1];
}

document.getElementById('t1').innerHTML=arr1[0];
document.getElementById('t2').innerHTML=arr2[0];
document.getElementById('t3').innerHTML=arr3[0];
document.getElementById('t4').innerHTML=arr4[0];
document.getElementById('t5').innerHTML=arr1[1];
document.getElementById('t6').innerHTML=arr2[1];
document.getElementById('t7').innerHTML=arr3[1];
document.getElementById('t8').innerHTML=arr4[1];
document.getElementById('t9').innerHTML=arr1[2];
document.getElementById('t10').innerHTML=arr2[2];
document.getElementById('t11').innerHTML=arr3[2];
document.getElementById('t12').innerHTML=arr4[2];
document.getElementById('t13').innerHTML=arr1[3];
document.getElementById('t14').innerHTML=arr2[3];
document.getElementById('t15').innerHTML=arr3[3];
document.getElementById('t16').innerHTML=arr4[3];

document.getElementById('t17').innerHTML=arr5[0];
document.getElementById('t18').innerHTML=arr6[0];
document.getElementById('t19').innerHTML=arr7[0];
document.getElementById('t20').innerHTML=arr8[0];
document.getElementById('t21').innerHTML=arr5[1];
document.getElementById('t22').innerHTML=arr6[1];
document.getElementById('t23').innerHTML=arr7[1];
document.getElementById('t24').innerHTML=arr8[1];
document.getElementById('t25').innerHTML=arr5[2];
document.getElementById('t26').innerHTML=arr6[2];
document.getElementById('t27').innerHTML=arr7[2];
document.getElementById('t28').innerHTML=arr8[2];
document.getElementById('t29').innerHTML=arr5[3];
document.getElementById('t30').innerHTML=arr6[3];
document.getElementById('t31').innerHTML=arr7[3];
document.getElementById('t32').innerHTML=arr8[3];


document.getElementById('i1').src='./img/'+arr1[0]+'.png';
document.getElementById('i2').src='./img/'+arr2[0]+'.png';
document.getElementById('i3').src='./img/'+arr3[0]+'.png';
document.getElementById('i4').src='./img/'+arr4[0]+'.png';
document.getElementById('i5').src='./img/'+arr1[1]+'.png';
document.getElementById('i6').src='./img/'+arr2[1]+'.png';
document.getElementById('i7').src='./img/'+arr3[1]+'.png';
document.getElementById('i8').src='./img/'+arr4[1]+'.png';
document.getElementById('i9').src='./img/'+arr1[2]+'.png';
document.getElementById('i10').src='./img/'+arr2[2]+'.png';
document.getElementById('i11').src='./img/'+arr3[2]+'.png';
document.getElementById('i12').src='./img/'+arr4[2]+'.png';
document.getElementById('i13').src='./img/'+arr1[3]+'.png';
document.getElementById('i14').src='./img/'+arr2[3]+'.png';
document.getElementById('i15').src='./img/'+arr3[3]+'.png';
document.getElementById('i16').src='./img/'+arr4[3]+'.png';

document.getElementById('i17').src='./img/'+arr5[0]+'.png';
document.getElementById('i18').src='./img/'+arr6[0]+'.png';
document.getElementById('i19').src='./img/'+arr7[0]+'.png';
document.getElementById('i20').src='./img/'+arr8[0]+'.png';
document.getElementById('i21').src='./img/'+arr5[1]+'.png';
document.getElementById('i22').src='./img/'+arr6[1]+'.png';
document.getElementById('i23').src='./img/'+arr7[1]+'.png';
document.getElementById('i24').src='./img/'+arr8[1]+'.png';
document.getElementById('i25').src='./img/'+arr5[2]+'.png';
document.getElementById('i26').src='./img/'+arr6[2]+'.png';
document.getElementById('i27').src='./img/'+arr7[2]+'.png';
document.getElementById('i28').src='./img/'+arr8[2]+'.png';
document.getElementById('i29').src='./img/'+arr5[3]+'.png';
document.getElementById('i30').src='./img/'+arr6[3]+'.png';
document.getElementById('i31').src='./img/'+arr7[3]+'.png';
document.getElementById('i32').src='./img/'+arr8[3]+'.png';

document.getElementById("btn").addEventListener("click", myFunction);


}





 




//var f=document.getElementById('image2');

 //document.getElementById("image1").src=f;
 













